This project contains the `final_pipeline.py` script, which serves as the main program. Before running the script, make sure to install all the dependencies listed in `requirements.txt`.
the output has been parsed locally and put to json file for submission.
Taxonomy has many more classes that has been used for finer classes of artifacts

## Installation

1. Clone or download this folder to your local machine.
2. Open a terminal and navigate to the project directory.

3 .to install requirements

pip install -r requirements.txt

4 .run inference 

python final_pipeline.py

the files have placeholders for the models or safetensors, image paths and so on you have to put it there for inference




